#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>


////trabajo opencv
#include <opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <opencv/highgui.h>

#include <opencv2/objdetect/objdetect.hpp>
//#include <opencv2/highgui/highgui_c.h>


namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

private:
    Ui::Dialog *ui;
    cv::Mat Original;
    cv::Mat GrayScal;
    cv::CascadeClassifier face_cascade;
    cv::VideoCapture webcam;
    QImage qtimageno;
    QImage imagenCam;
    std::vector<cv::Rect> faces;
    std::vector<cv::Rect>::iterator faceitr;
    int Conta=0;

    QTimer* tmrTimer;

public slots:

    void Deteccionface();


private slots:
    void on_btnPlay_clicked();
};

#endif // DIALOG_H
