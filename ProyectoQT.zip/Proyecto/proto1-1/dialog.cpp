#include "dialog.h"
#include "ui_dialog.h"

#include <QtCore>

//Author Ing. Emmanuel Baleon Flores
//Metodo Cascade classification
//Universidad Politécnica de Puebla // MISCI
//Proyecto Reconocimiento de expreciones faciales

Dialog::Dialog(QWidget *parent) :QDialog(parent),ui(new Ui::Dialog)
{
    ui->setupUi(this);



    //insertar video :D

    QPixmap pix("/home/emmanuel/Qtprototipo/image/1.jpg");
    ui->Vdeo->setPixmap(pix);

   //caragar el archivo XML
    face_cascade.load("/home/emmanuel/Documentos/data+/cascade.xml");
    if(face_cascade.empty()){
        ui->mensajes->appendPlainText("Error en XML");
            face_cascade.load("/home/emmanuel/Documentos/data+/cascade.xml");
    }





    tmrTimer = new QTimer(this);


}

void Dialog::Deteccionface(){





    //leer imagen
    webcam.read(Original);

    if(Original.empty()==true)return;

   cv::cvtColor(Original, GrayScal, CV_BGR2GRAY);
    cv::equalizeHist(GrayScal, GrayScal);

    std::vector<cv::Rect> caras;
      float scaleFactor = 3.0f;

      face_cascade.detectMultiScale( GrayScal, faces, 1.1,3,0,cv::Size(160,160));
  if(faces.size()==0){
      QPixmap pix3("/home/emmanuel/Qtprototipo/image/normal.jpg");
      ui->emocion->setPixmap(pix3);
       //ui->emocion->clear();
    }


    for(size_t i=0;i<faces.size(); i++){





      cv::rectangle(Original,cv::Rect(faces[i].x,faces[i].y,faces[i].width,faces[i].height),cv::Scalar(0,215,255),3,1,0);

      cv::putText(Original,"Feliz",cv::Point(faces[i].x,faces[i].y),cv::FONT_HERSHEY_COMPLEX,3,CV_RGB(255,69,0), 3);
      //Contador
        Conta++;
        ui->mensajes->clear();
       ui->mensajes->appendPlainText("Numéro Caras Felices :D "+QString::number(Conta));

        //imagen
         QPixmap pix2("/home/emmanuel/Qtprototipo/image/feliz2.jpg");
         ui->emocion->setPixmap(pix2);

    }



   // ui->mensajes->appendPlainText(time);

    //imagen


    cv::cvtColor(Original,Original,CV_BGR2RGB);

    QImage qtimageno((uchar*) Original.data,Original.cols, Original.rows,Original.step, QImage::Format_RGB888);
    //QImage qtProccess ((uchar *) matprocecess.data,original.cols, matprocecess.rows,matprocecess.step, QImage::Format_Indexed8);
    ui->Vdeo->setPixmap(QPixmap::fromImage(qtimageno));


}


Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_btnPlay_clicked()
{
    if(tmrTimer->isActive() == false){

       // tmrTimer->stop();
        //ui->btnpause->setText("Resumen");
        //accerder a foxcam
       //webcam.open("http://admin:@192.168.1.107/video.cgi?.mjpg");
        //webcam.open("http://localhost:8081/video.cgi?");
                            //video.cgi?resolution=640x360&req_fps=50&.mjpg
       //?action=stream?dummy=param.mjpg
       webcam.open(0);
       while(webcam.isOpened()!=true){
           ui->mensajes->appendPlainText("Error Camara :'(");
           //return;
       }

       //webcam.get(CV_CAP_PROP_POS_MSEC);
        ui->btnPlay->setText("Stop");

        //inicia la señal
        connect(tmrTimer,SIGNAL(timeout()),this,SLOT(Deteccionface()) );

          tmrTimer->start(20);

    }
    else{
           tmrTimer->stop();

           QPixmap pix("/home/emmanuel/Qtprototipo/image/1.jpg");

         // if( pix.isNull()){
           // ui->mensajes->appendPlainText("Error Ruta");
         // }
           ui->btnPlay->setText("Play");
            webcam.~VideoCapture();
            ui->Vdeo->clear();
            Conta=0;
            ui->mensajes->clear();
            ui->Vdeo->setPixmap(pix);
    }


}
