/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLabel *Vdeo;
    QPushButton *btnPlay;
    QPlainTextEdit *mensajes;
    QLabel *emocion;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(1000, 600);
        Vdeo = new QLabel(Dialog);
        Vdeo->setObjectName(QStringLiteral("Vdeo"));
        Vdeo->setGeometry(QRect(10, 0, 640, 480));
        Vdeo->setLayoutDirection(Qt::LeftToRight);
        Vdeo->setAutoFillBackground(true);
        btnPlay = new QPushButton(Dialog);
        btnPlay->setObjectName(QStringLiteral("btnPlay"));
        btnPlay->setGeometry(QRect(10, 510, 141, 71));
        mensajes = new QPlainTextEdit(Dialog);
        mensajes->setObjectName(QStringLiteral("mensajes"));
        mensajes->setGeometry(QRect(230, 500, 281, 78));
        emocion = new QLabel(Dialog);
        emocion->setObjectName(QStringLiteral("emocion"));
        emocion->setGeometry(QRect(660, 20, 321, 231));
        emocion->setLayoutDirection(Qt::LeftToRight);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Reconocimiento de Emociones 0.1", 0));
        Vdeo->setText(QString());
        btnPlay->setText(QApplication::translate("Dialog", "Play", 0));
        emocion->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
